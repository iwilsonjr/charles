<?php
/**
 * BackWPup_Destination_Dropbox_API_Exception
 */
class BackWPup_Destination_Dropbox_API_Exception extends Exception {

}
